# huntAI — Deployment Guide (read this first!)

## Why you were getting 404 errors

This app has two parts:

1. **Front end** — `index.html`, `style.css`, `script.js` (what you see in the browser)
2. **Back end** — `netlify/functions/chat.js` (a serverless function that talks to Google's Gemini API)

The front end calls `/.netlify/functions/chat`. **This path only exists once the
project is deployed on Netlify.** If you open `index.html` by double-clicking it,
or host it on plain static hosting (GitHub Pages, a basic web server, etc.),
that function does not exist there — so every message gives a 404. This is
almost certainly what was happening.

**The fix: deploy this exact folder to Netlify.** Follow the steps below exactly
and it will work.

---

## Step 1 — Get a Gemini API key

1. Go to https://aistudio.google.com/apikey
2. Sign in and click "Create API key"
3. Copy the key — you'll need it in Step 3

## Step 2 — Deploy to Netlify (drag-and-drop method, easiest)

1. Go to https://app.netlify.com and sign up / log in (free)
2. Click **"Add new site" → "Deploy manually"**
3. Drag the **entire `huntAI_fixed` folder** (this whole folder, not a zip) onto the upload area
   - If you only have the zip, unzip it first — Netlify needs the actual files/folders, not a `.zip`
4. Netlify will publish it and give you a URL like `random-name-123.netlify.app`

## Step 3 — Add your API key as an environment variable

The API key must NOT be pasted directly into `chat.js` — it must be set as an
environment variable, or it won't work (and would be exposed publicly if it did).

1. In Netlify, go to **Site configuration → Environment variables**
2. Click **"Add a variable"**
3. Key: `GEMINI_API_KEY`
   Value: *(paste the key from Step 1)*
4. Click **Save**
5. Go to **Deploys** tab → click **"Trigger deploy" → "Deploy site"**
   (this step is required — the function only picks up the key on a fresh deploy)

## Step 4 — Test it

Open your `netlify.app` URL, type a message, hit Send. You should see a typing
indicator, then a real Gemini reply. No 404.

---

## If you still see an error

The chat window will now show you *why*, instead of just failing silently:

- **"chat function isn't reachable"** → you're not viewing the site through
  its Netlify URL (e.g. you opened the local file instead)
- **"Server error: ..."** → the function ran but Gemini rejected the request —
  usually means `GEMINI_API_KEY` is missing/wrong, or you skipped the
  "Trigger deploy" step after adding it
- **"Can't reach the server"** → no internet connection, or the site isn't
  deployed yet

## Alternative: deploy with Netlify CLI (if you prefer command line)

```bash
npm install -g netlify-cli
cd huntAI_fixed
netlify deploy --prod
```

Then set the environment variable the same way as Step 3, either in the
Netlify dashboard or with:

```bash
netlify env:set GEMINI_API_KEY your_key_here
netlify deploy --prod
```
