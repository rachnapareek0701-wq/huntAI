const chatBox = document.getElementById("chat");
const input = document.getElementById("msg");
const sendBtn = document.getElementById("sendBtn");

function addMessage(text, sender) {
  const div = document.createElement("div");
  div.className = `message ${sender}`;
  div.textContent = text;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
  return div;
}

function showTyping() {
  const div = document.createElement("div");
  div.className = "message ai typing";
  div.id = "typingIndicator";
  div.innerHTML = `<span class="dots"><span></span><span></span><span></span></span>`;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function removeTyping() {
  const el = document.getElementById("typingIndicator");
  if (el) el.remove();
}

async function send() {
  const userMessage = input.value.trim();
  if (!userMessage) return;

  addMessage(userMessage, "user");
  input.value = "";
  sendBtn.disabled = true;
  showTyping();

  try {
    const res = await fetch("/.netlify/functions/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        message: userMessage
      })
    });

    if (res.status === 404) {
      throw new Error(
        "404: The chat function isn't reachable. This page must be running on Netlify " +
        "(not opened as a local file) for /.netlify/functions/chat to exist."
      );
    }
    if (!res.ok) {
      throw new Error(`Server responded with ${res.status}`);
    }

    const data = await res.json();
    removeTyping();

    if (data.error) {
      addMessage(`⚠️ Server error: ${data.error}`, "ai");
    } else {
      addMessage(data.reply || "No response received.", "ai");
    }

  } catch (err) {
    console.error(err);
    removeTyping();
    if (err.message.includes("Failed to fetch")) {
      addMessage(
        "⚠️ Can't reach the server. Make sure this site is deployed on Netlify (not opened as a local file).",
        "ai"
      );
    } else {
      addMessage(`⚠️ ${err.message}`, "ai");
    }
  } finally {
    sendBtn.disabled = false;
    input.focus();
  }
}

input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") send();
});
