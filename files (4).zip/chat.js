// api/chat.js
// This runs on Vercel's server, NOT in the browser — so it's safe to use your API key here.

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "Missing GEMINI_API_KEY environment variable" });
  }

  try {
    const { history } = req.body;

    // Convert our simple {role, content} history into Gemini's expected format.
    // Gemini uses "user" and "model" as roles (not "assistant").
    const contents = (history || []).map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }));

    const systemInstruction = {
      parts: [
        {
          text: "You are huntAI, a sharp, focused AI assistant. You help people track down answers, debug problems, and cut through noise. Keep a confident, precise, no-fluff tone without being curt.",
        },
      ],
    };

    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents,
          systemInstruction,
        }),
      }
    );

    const data = await geminiRes.json();

    if (!geminiRes.ok) {
      console.error("Gemini API error:", data);
      return res.status(geminiRes.status).json({ error: data.error?.message || "Gemini API error" });
    }

    const replyText =
      data.candidates?.[0]?.content?.parts?.map((p) => p.text || "").join("") ||
      "No response generated.";

    return res.status(200).json({ reply: replyText });
  } catch (err) {
    console.error("Server error:", err);
    return res.status(500).json({ error: "Server error contacting Gemini" });
  }
}
