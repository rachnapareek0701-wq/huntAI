# huntAI

Full-stack setup: neon chat UI + Express backend that calls the Anthropic API.

## Structure
```
huntai-backend/
├── server.js         # Express server, handles POST /api/chat
├── package.json
├── .env.example      # copy to .env and add your API key
└── public/
    ├── index.html    # the huntAI chat UI
    └── script.js     # frontend logic (send/render/error handling)
```

## Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Add your API key:
   ```
   cp .env.example .env
   ```
   Then open `.env` and set `ANTHROPIC_API_KEY=sk-ant-...` with your real key
   from https://console.anthropic.com/settings/keys

3. Start the server:
   ```
   npm start
   ```

4. Open http://localhost:3000 in your browser. The page is served directly
   by the backend, so there's no separate frontend server needed.

## Notes

- The model defaults to `claude-sonnet-4-6`. Change `ANTHROPIC_MODEL` in `.env`
  to use a different one.
- Never commit your real `.env` file — it contains your secret API key.
- If you'd rather use OpenAI instead of Anthropic, the only file that needs
  to change is `server.js` — the fetch call and response parsing would need
  updating to match OpenAI's `/v1/chat/completions` format. Let me know if
  you want that swapped in instead.
